require('./angular-locale_aa-er');
module.exports = 'ngLocale';
