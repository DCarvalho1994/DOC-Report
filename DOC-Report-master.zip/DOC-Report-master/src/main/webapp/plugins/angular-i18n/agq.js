require('./angular-locale_agq');
module.exports = 'ngLocale';
