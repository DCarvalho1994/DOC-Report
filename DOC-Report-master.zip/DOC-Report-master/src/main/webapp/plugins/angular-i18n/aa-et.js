require('./angular-locale_aa-et');
module.exports = 'ngLocale';
