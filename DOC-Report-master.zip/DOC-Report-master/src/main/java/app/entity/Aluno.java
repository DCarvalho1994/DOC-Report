package app.entity;

import java.io.*;
import javax.persistence.*;
import java.util.*;
import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonFilter;
import cronapi.rest.security.CronappSecurity;


/**
 * Classe que representa a tabela ALUNO
 * @generated
 */
@Entity
@Table(name = "\"ALUNO\"" ,uniqueConstraints=@UniqueConstraint(columnNames={
"matricula" ,"cpF" ,"email" }))
@XmlRootElement
@CronappSecurity
@JsonFilter("app.entity.Aluno")
public class Aluno implements Serializable {

  /**
   * UID da classe, necessário na serialização
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * @generated
   */
  @Id
  @Column(name = "id", nullable = false, insertable=true, updatable=true)
  private java.lang.String id = UUID.randomUUID().toString().toUpperCase();

  /**
  * @generated
  */
  @Column(name = "nome", nullable = false, unique = false, insertable=true, updatable=true)
  
  private java.lang.String nome;

  /**
  * @generated
  */
  @Column(name = "matricula", nullable = false, unique = true, insertable=true, updatable=true)
  
  private java.lang.String matricula;

  /**
  * @generated
  */
  @Column(name = "CPF", nullable = false, unique = true, insertable=true, updatable=true)
  
  private java.lang.String cpF;

  /**
  * @generated
  */
  @Column(name = "photo", nullable = false, unique = false, insertable=true, updatable=true)
  
  private byte[] photo;

  /**
  * @generated
  */
  @Column(name = "email", nullable = false, unique = true, insertable=true, updatable=true)
  
  private java.lang.String email;

  /**
  * @generated
  */
  @Column(name = "idade", nullable = false, unique = false, insertable=true, updatable=true)
  
  private java.lang.String idade;

  /**
  * @generated
  */
  @Temporal(TemporalType.DATE)
  @Column(name = "birthday", nullable = false, unique = false, insertable=true, updatable=true)
  
  private java.util.Date birthday;

  /**
  * @generated
  */
  @ManyToOne
  @JoinColumn(name="fk_curso", nullable = true, referencedColumnName = "id", insertable=true, updatable=true)
  
  private Curso curso;

  /**
   * Construtor
   * @generated
   */
  public Aluno(){
  }


  /**
   * Obtém id
   * return id
   * @generated
   */
  
  public java.lang.String getId(){
    return this.id;
  }

  /**
   * Define id
   * @param id id
   * @generated
   */
  public Aluno setId(java.lang.String id){
    this.id = id;
    return this;
  }

  /**
   * Obtém nome
   * return nome
   * @generated
   */
  
  public java.lang.String getNome(){
    return this.nome;
  }

  /**
   * Define nome
   * @param nome nome
   * @generated
   */
  public Aluno setNome(java.lang.String nome){
    this.nome = nome;
    return this;
  }

  /**
   * Obtém matricula
   * return matricula
   * @generated
   */
  
  public java.lang.String getMatricula(){
    return this.matricula;
  }

  /**
   * Define matricula
   * @param matricula matricula
   * @generated
   */
  public Aluno setMatricula(java.lang.String matricula){
    this.matricula = matricula;
    return this;
  }

  /**
   * Obtém cpF
   * return cpF
   * @generated
   */
  
  public java.lang.String getCpF(){
    return this.cpF;
  }

  /**
   * Define cpF
   * @param cpF cpF
   * @generated
   */
  public Aluno setCpF(java.lang.String cpF){
    this.cpF = cpF;
    return this;
  }

  /**
   * Obtém photo
   * return photo
   * @generated
   */
  
  public byte[] getPhoto(){
    return this.photo;
  }

  /**
   * Define photo
   * @param photo photo
   * @generated
   */
  public Aluno setPhoto(byte[] photo){
    this.photo = photo;
    return this;
  }

  /**
   * Obtém email
   * return email
   * @generated
   */
  
  public java.lang.String getEmail(){
    return this.email;
  }

  /**
   * Define email
   * @param email email
   * @generated
   */
  public Aluno setEmail(java.lang.String email){
    this.email = email;
    return this;
  }

  /**
   * Obtém idade
   * return idade
   * @generated
   */
  
  public java.lang.String getIdade(){
    return this.idade;
  }

  /**
   * Define idade
   * @param idade idade
   * @generated
   */
  public Aluno setIdade(java.lang.String idade){
    this.idade = idade;
    return this;
  }

  /**
   * Obtém birthday
   * return birthday
   * @generated
   */
  
  public java.util.Date getBirthday(){
    return this.birthday;
  }

  /**
   * Define birthday
   * @param birthday birthday
   * @generated
   */
  public Aluno setBirthday(java.util.Date birthday){
    this.birthday = birthday;
    return this;
  }

  /**
   * Obtém curso
   * return curso
   * @generated
   */
  
  public Curso getCurso(){
    return this.curso;
  }

  /**
   * Define curso
   * @param curso curso
   * @generated
   */
  public Aluno setCurso(Curso curso){
    this.curso = curso;
    return this;
  }

  /**
   * @generated
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;
    Aluno object = (Aluno)obj;
    if (id != null ? !id.equals(object.id) : object.id != null) return false;
    return true;
  }

  /**
   * @generated
   */
  @Override
  public int hashCode() {
    int result = 1;
    result = 31 * result + ((id == null) ? 0 : id.hashCode());
    return result;
  }

}
